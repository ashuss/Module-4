package com.cg.springmvctwo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvctwo.dto.Mobile;
import com.cg.springmvctwo.service.IMobileService;

@Controller
public class MobileController 
{
	@Autowired
	IMobileService mobileservice;
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView allMobileData()
	{
		List<Mobile> mobData = mobileservice.showAllMobile();
		return new ModelAndView("mobileshow", "temp", mobData);		//(jsp page,temporary list, actual data)
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id") int mobid)
	{
		//System.out.println("id is : "+mobid);
		mobileservice.deletMobile(mobid);
		return "redirect:/showall";
	}
}
