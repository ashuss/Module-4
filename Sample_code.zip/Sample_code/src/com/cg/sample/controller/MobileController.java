package com.cg.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.sample.service.IMobileService;
import com.cg.sample.dto.Mobile;

@Controller
public class MobileController
{
	@Autowired
	IMobileService mobileservice;
	
	@RequestMapping(value="Home",method=RequestMethod.GET)
	public ModelAndView allMobileData()
	{
		List<Mobile> mobData = mobileservice.showAllMobile();
		return new ModelAndView("mobileshow", "temp", mobData);		//(jsp page,temporary list, actual data)
	}

	@RequestMapping(value="update", method=RequestMethod.GET)
	public ModelAndView updateTrainee(@RequestParam("id") int mid, @ModelAttribute("myUpdate") Mobile mob)
	{
		List<Mobile> myAllData = mobileservice.showMobileById(mid);
		return new ModelAndView("updateMobile","temp1",myAllData);
	}

@RequestMapping(value="updated", method=RequestMethod.POST)
    public String update(@ModelAttribute("myUpdate") Mobile mob)
    {
        mobileservice.updateMobile(mob);
        return "success";
    }  
	       
	
}
