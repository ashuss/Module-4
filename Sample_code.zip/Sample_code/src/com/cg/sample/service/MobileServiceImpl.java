package com.cg.sample.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sample.dao.IMobileDao;
import com.cg.sample.dto.Mobile;

@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements IMobileService
{
	@Autowired
	IMobileDao mobiledao;
	
	@Override
	public List<Mobile> showAllMobile() 
	{
		return mobiledao.showAllMobile();
	}

	@Override
	public void updateMobile(Mobile mob) 
	{
		mobiledao.updateMobile(mob);
	}

	@Override
	public List<Mobile> showMobileById(int mobId) 
	{
		return mobiledao.showMobileById(mobId);
	}

}
