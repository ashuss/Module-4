package com.cg.sample.service;

import java.util.List;

import com.cg.sample.dto.Mobile;

public interface IMobileService 
{
	public List<Mobile> showAllMobile();
	public void updateMobile(Mobile mob);
	public List<Mobile> showMobileById(int mobId);
}
