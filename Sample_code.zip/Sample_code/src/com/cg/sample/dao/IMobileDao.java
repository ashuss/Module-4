package com.cg.sample.dao;

import java.util.List;
import com.cg.sample.dto.Mobile;



public interface IMobileDao 
{
	public List<Mobile> showAllMobile();
	public void updateMobile(Mobile mob);
	public List<Mobile> showMobileById(int mobId);
}
