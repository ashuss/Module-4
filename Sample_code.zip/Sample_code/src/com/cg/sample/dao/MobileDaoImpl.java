package com.cg.sample.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.sample.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<Mobile> showAllMobile() 
	{
		Query queryOne=entitymanager.createQuery("FROM Mobile");
		List<Mobile> myList = queryOne.getResultList();
		return myList;
	}

	@Override
	public void updateMobile(Mobile mob) 
	{
		entitymanager.merge(mob);
		entitymanager.flush();
	}

	@Override
	public List<Mobile> showMobileById(int mobId) 
	{
		Query queryTwo=entitymanager.createQuery("Select m FROM Mobile m WHERE id=:mId");
		queryTwo.setParameter("mId", mobId);
		
		 List<Mobile> myList1 = queryTwo.getResultList();
		 return myList1;
	}

}
